const Hotels = () => {
  return (
    <div id="hotels">
      Hotels
    </div>
  )
}

export default Hotels
